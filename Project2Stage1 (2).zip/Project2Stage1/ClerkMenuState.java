import java.util.Scanner;
import java.util.Random;

public class ClerkMenuState {
 
    // Main 
    public static void InClerk(){


      
    }
}
