import java.util.Scanner;

// Login UI
public class Main {
  
    public static Client client = new Client("", "", "", "", 0); 
    public static ClientList cList = new ClientList();
    public static productList pList =  new productList();
    public static  Main in = new Main();

    // Reference Objecct
    public static Client clientObject(String name) {return cList.searchClient(name); };
    public static ClientList cListObj() {return cList; }; 
    public static productList pListObj() {return pList; };
    public static Main mainObj() {return in; };

    String cName, cID; 
   
    /*
    public void clientLog(String Name, String ID, Client Reference){
        this.cName = Name;
        this.cID = ID; 
        this.cReference = Reference;
    }
    */

    public void clientInfor(String cName, String cID){
      this.cName = cName;
      this.cID = cID; 
    }

     // Getter
    public String getCName() {return this.cName; };
    public String getCID() {return this.cID; };

    // UI Menu
    public int menu(){

        int choice;

        System.out.println("\nUI: ");
        System.out.println("====");
        System.out.println("Please Choose An Option Below: ");
        System.out.println("Enter 1 For Client");
        System.out.println("Enter 2 For Clerk");
        System.out.println("Enter 3 For Manager");
        System.out.println("Enter 0 To Exit");
        Scanner in = new Scanner(System.in);
        choice = in.nextInt();

        return choice;
    }

    // User Pick An Option
    public static void option(Main in){

        int chosen = in.menu();

        while (chosen != 0){

            switch(chosen){
                // Client
                case 1: 
                    System.out.print("Enter The Client Name: ");
                    Scanner in1 = new Scanner(System.in);
                    String cName1 = in1.nextLine(); 
                    System.out.print("Enter The Client ID: ");
                    String cID1 = in1.nextLine();
                    in.clientInfor(cName1, cID1);
                    ClientMenuState.InClient();
                    break;

                // Clerk
                case 2:
                    break;

                // Manager
                case 3:
                    break;
                default :
                    System.out.println("Invaild Entry");
                    break;
            }
        }
    }

    public static void main(String[] args){
        
    //Load Database Contain Client List + Product List
       LoadData.run(cList, pList);

        // products prod1 = new products("Pen","P1245", "Ball-point Pen", 100, 1.75 );
        // products prod2 = new products("NoteBook","P3267", "College Ruled 80 page", 200, 3.75 );


        // productList s1 = new productList();

        // SupplierList sup1 = new SupplierList();
        // Supplier sr1 = new Supplier("12345","tomas","adressa");
        // s1.addProductList(prod1);
        // s1.addProductList(prod2);

        // s1.displayAllProductList();


        // sr1.AssignProduct(prod1);
        // sr1.AssignProduct(prod2);
	    // System.out.println(sr1.getProductPrice("Pen") + "\n");
	    // 	System.out.println(sr1.getProductPrice("NoteBook") + "\n");


      

       // Supplier(String id, String name, String address);

        //Client, Clerk, Manager Login
        Main.option(mainObj());

        

    } 
}
