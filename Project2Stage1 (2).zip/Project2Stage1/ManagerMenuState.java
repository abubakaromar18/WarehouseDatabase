public class ManagerMenuState {
    
}
